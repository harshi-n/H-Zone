       	                      							H ZONE creatated by Harshin Hari
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
H ZONE is a contact management application that allows users to register, login, and add their contacts. The login details and contacts will be stored in a local database.

To use the application, extract the zip file attached to this note to a folder and run the application(hzone).
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
H ZONE is built in Windows forms and uses an MS Access database.The tools required are Microsoft Visual Studio 2015 and MS Access. The UI and programming parts are done in

Visual Studio and the database is created in MS ACCESS.It required three windows forms for the registration, login, and contact form. In the registration window,

users have to create an account by submitting a user id and password.The registered users  can login to their account by clicking "back to log in" icon.After login a user

can add their contacts by filling the form in the third window. The registration credentials(username and passwords) is stored in the locala data base named db_users and 

contact details is stored in a database named db_cform.All the programs and database required for the apllication is attached with this note.